
sbit		LcdRS	=	0x80;	//P0_0
sbit		LcdRW	=	0x81;	//P0_1
sbit		LcdEN	=	0x82;	//P0_5
sfr			LcdPort	=	0xA0;	//Port2

unsigned char M[30];

void LcdDelay(unsigned int t)
{
unsigned int i;
for(i=0;i<=t;i++);
}

//------------
bit	LcdBusy()
{
bit BF;
LcdPort=0xfF;

LcdRW=1;
LcdRS=0;
//
LcdEN=1;	LcdDelay(50);
BF=0;		BF=LcdPort&0x80;
LcdEN=0;	LcdDelay(50);

return(BF);
}

//----------
void LcdWr(unsigned char D)
{
LcdPort=D;
LcdEN=1;	LcdDelay(50);
LcdEN=0;	LcdDelay(50);
}

//----------
void LcdWrCmd(unsigned char LcdCmd)
{
while(LcdBusy());
LcdRW=0;
LcdRS=0;
LcdWr(LcdCmd);
}

//----------
void LcdWrData(unsigned char LcdData)
{
while(LcdBusy());
LcdRW=0;
LcdRS=1;
LcdWr(LcdData);
}

//----------
void LcdWrStr(unsigned char *s)
{
while(*s)
	{
	LcdWrData(*s);
	s++;
	}
}

//----------
void LcdClr()
{
LcdWrCmd(0x01);
}

//----------
void LcdGoto(char y, char x)
{
char N[3]={0,0x80,0xC0};
LcdWrCmd(N[y]+x);
}

//----------
void LcdInit()
{
LcdRS=0;
LcdRW=0;
LcdEN=0;

//LcdWrCmd(0x01);
//LcdDelay(50);
//
LcdWrCmd(0x02);
//
LcdDelay(50);
LcdWrCmd(0x0c);//display on, cursor off, brink off
//
LcdDelay(50);
LcdWrCmd(0x38);//interface 8 bits, 2 lines, 5x7 dots

//LcdWrCmd(0x03);
LcdWrCmd(0x01);//clear display and return to top-left
}
