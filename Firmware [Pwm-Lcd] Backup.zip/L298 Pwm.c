#include	"REGX52.H"
#include	"stdio.H"
#include <LCD_4bit_Interface.H>

sbit		PWM		=P2^6;
sbit		DIR		=P2^7;
sbit		KMode	=P1^0;//On/Off
sbit		KUp		=P1^1;//Up
sbit		KDown	=P1^2;//Down
sbit		KDir	=P1^3;//Direct

unsigned int	Counter,Speed,Duty;
unsigned char Direct;
unsigned char		pMode,pDown,pDir=0,pUp;

//unsigned char	Mode,Up,Down,Direct;		

#define		Fwd		0x41
#define		Rev		0x42
#define		Mode	0x01
#define		Up		0x02
#define		Down	0x04
#define		Dir		0x08	


void Delay(unsigned int t)
{
unsigned int i;
for(i=0;i<=t;i++);
}

//-------------
/*
Tao xung PWM co f=500Hz =>T=2ms
20 cap toc do, => Thoi gian tran Timer=2ms/20=100uS
Dung Timer0 che do 2 (8bit Auto Reload)
*/
void Configure(void)
{
TMOD=0x02;	//Timer0 che do 2 (Tu nap lai)
IE=0x82;	//Cho phep ngat timer0
TH0=TL0=155;
TR0=0;		//0 Cho phep Timer 0 chay
}


//-------------
void	Run(unsigned char Direct,unsigned int Duty1)//20 cap toc do
{
TR0=1;
if(Direct==Fwd)
	{
	DIR=0;
	Duty=Duty1;
	}

if(Direct==Rev)
	{
	DIR=1;
	Duty=20-Duty1;
	}
}


//-------------
void Stop(void)
{
TR0=0;
PWM=0;
DIR=0;
}


//-------------

unsigned int GetKey(void)
{
unsigned int n=0,nMode=0,nUp=0,nDown=0,nDir=0,nKey=0;
nMode=nUp=nDown=nDir=0;

//-----
for(n=0;n<=6000;n++)
	{
	if(!KMode)	nMode++;
	if(!KUp)	nUp++;
	if(!KDown)	nDown++;
	if(!KDir)	nDir++;
	}
if(nMode>3000)	nKey |=Mode;
if(nUp>3000)	nKey |=Up;
if(nDown>3000)	nKey |=Down;
if(nDir>3000)	nKey |=Dir;

return(nKey);
}


////-------------
//void Test(void)
//{
//unsigned int k;
//
//for(k=5;k<=20;k++)
//	{
//	Run(Fwd,k);Delay(10000);
//	}
//Stop();Delay(20000);
//
//for(k=5;k<=20;k++)
//	{
//	Run(Rev,k);Delay(10000);
//	}
//Stop();Delay(20000);
//}

void CheckKey(void)
{
unsigned int Key;

//Key=GetKey();

if((Key &0x01)==0x01)	pMode=!pMode;


if(pMode)
	{
	LcdClr();
	do
		{
		Key=GetKey();
		//if((Key &0x01)==0x01)	pMode=!pMode;

		if((Key &0x02)==0x02)	
			{
			 if(Speed<20) Speed ++;
			}
	
		if((Key &0x04)==0x04)
			{
			if(Speed>1)	Speed--;
			}
	
		if((Key & 0x08)==0x08) pDir=!pDir;
	
		//---
		if(pDir)	Direct=Fwd;
		else		Direct=Rev;
	
			
		Run(Direct,Speed);
	
		LcdGoto(1,6);
		sprintf(&M[0],"Duty  %d%c  ",Speed*5,0x25);
		LcdWrStr(&M[0]);

		LcdGoto(0,13); 	if(Direct==Fwd){LcdWrStr("Fwd");};
						if(Direct==Rev){LcdWrStr("Rev");};

		LcdGoto(0,0);LcdWrStr("Run...");
		}
	while((Key&0x01)!=0x01);
	}

	//-----

if(!pMode)
	{
	Stop();
	LcdClr();
	LcdGoto(0,0);LcdWrStr("Stop !");
		do
		{
			{
			Key=GetKey();
			//if((Key &0x01)==0x01)	pMode=!pMode;
			}
		}
		while((Key&0x01)!=0x01);
	}
//if(Key &0x01==0x01)		pMode=!pMode;
//if(Key &0x02==0x02)		{if(Speed<20) Speed+=1;};
//if(Key &0x04==0x04)		{if(Speed>1) Speed-=1;};
//if(Key &0x08==0x08)		pDir=!pDir;
}

//-------------
//void Control(void)
//{
//;
//}
//-------------
void main(void)
{
Delay(10);
Configure();
LcdInit();

LcdClr();
LcdGoto(1,0);
LcdWrStr("DC Motor Control");

Stop();
Speed=5;//default
Direct=Fwd;
while(1)
	{
	CheckKey();
//	Test();
//	while(!(ReadKey()&0x01));
//	LcdClr();
//	LcdGoto(1,0); LcdWrStr("Run...");
//	//---
//	do
//		{
//
//		Run(Fwd,5);
//		}
//	while(!(ReadKey()&0x01));
//	LcdClr();
//	LcdGoto(1,0); LcdWrStr("Stop");
//	Stop();
	}
}


//-------------
void Timer0_Int(void) interrupt 1
{
Counter++;
if(Counter>=20)
	{
	Counter=0;
	}

if(Counter<Duty) 	PWM=1;
else				PWM=0;
}